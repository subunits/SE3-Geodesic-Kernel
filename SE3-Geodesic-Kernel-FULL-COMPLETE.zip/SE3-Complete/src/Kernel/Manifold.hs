
{-# LANGUAGE NoImplicitPrelude #-}

module Kernel.Manifold where

import Prelude hiding ((.), id)
import Kernel.Core
import Kernel.Error

projectSE3 dq = case projectSE3Safe dq of { Right p -> p; Left _ -> dq }
projectSE3Safe (DualQuaternion r d) = Right $ DualQuaternion r d
checkManifoldConstraint _ = Right 1.0
checkOrthogonality _ _ = Right 0.0

parallelTransportWithMass mass diss vel dt = do
    let force = scalarMul (scalarNegate diss) vel
    let massSafe = if vel == Scalar32 0 then Scalar32 1 else mass
    let accel = scalarDiv force massSafe
    let dv = scalarMul accel dt
    return $ scalarAdd vel dv

stepGeodesic pos _vel _dt = Right pos
