
{-# LANGUAGE OverloadedStrings #-}

module Main where

import Test.Tasty
import Test.Tasty.HUnit

main :: IO ()
main = defaultMain tests

tests :: TestTree
tests = testGroup "Unit Tests" [scalarTests, quaternionTests, manifestTests]

scalarTests :: TestTree
scalarTests = testGroup "Scalars" [testCase "addition" $ True @? "Scalar addition works"]

quaternionTests :: TestTree
quaternionTests = testGroup "Quaternions" [testCase "normalization" $ True @? "Quaternion normalization works"]

manifestTests :: TestTree
manifestTests = testGroup "Manifolds" [testCase "projection" $ True @? "Manifold projection works"]
