
{-# LANGUAGE NoImplicitPrelude #-}

module Main where

import Prelude

main :: IO ()
main = do
    putStrLn "=== SE(3) Geodesic Master Kernel Playground ==="
    putStrLn "✓ Playground working!"
