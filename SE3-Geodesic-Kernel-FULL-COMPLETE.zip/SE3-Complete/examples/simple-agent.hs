
module Examples.SimpleAgent where

main :: IO ()
main = putStrLn "Example: Simple agent"
