
{-# LANGUAGE NoImplicitPrelude #-}

module Kernel.Geodesic where

import Prelude hiding ((.), id)
import Kernel.Core
import Kernel.Error
import Kernel.Manifold

geodesicStep agent@Agent{..} callFreq dt = do
    let dissonance = scalarSub agentResonance callFreq
    vNew <- parallelTransportWithMass agentMass dissonance agentVel dt
    return $ agent { agentVel = vNew }

simulateSteps 0 agent _ _ = Right [agent]
simulateSteps n agent callFreq dt = do
    next <- geodesicStep agent callFreq dt
    rest <- simulateSteps (n-1) next callFreq dt
    return (agent : rest)

convergenceMetric ag1 ag2 = let v1 = fromScalar32 (agentVel ag1); v2 = fromScalar32 (agentVel ag2) in abs (v2 - v1)
hasConverged [] _ = False
hasConverged [_] _ = False
hasConverged traj tol = let diffs = zipWith convergenceMetric traj (tail traj); avgDiff = sum diffs / fromIntegral (length diffs) in avgDiff < tol

trajectoryEnergy Agent{..} callFreq = let vDouble = fromScalar32 agentVel; mDouble = fromScalar32 agentMass in 0.5 * mDouble * vDouble * vDouble
trajectoryStats [] = (0, 0, 0, 0)
trajectoryStats agents = let vels = map (fromScalar32 . agentVel) agents; n = fromIntegral (length vels); mean = sum vels / n; variance = sum [(v - mean)^2 | v <- vels] / n; stdDev = sqrt variance in (mean, stdDev, minimum vels, maximum vels)
