
{-# LANGUAGE NoImplicitPrelude #-}

module Kernel.DualQuaternion where

import Prelude hiding ((.), id)
import Kernel.Core

qNorm (Quaternion w x y z) = let ww = scalarMul w w; xx = scalarMul x x; yy = scalarMul y y; zz = scalarMul z z in scalarAdd (scalarAdd ww xx) (scalarAdd yy zz)
qNormalize q = let norm = qNorm q in if norm == Scalar32 0 then q else Quaternion (scalarDiv (qW q) norm) (scalarDiv (qX q) norm) (scalarDiv (qY q) norm) (scalarDiv (qZ q) norm)
dqCompose (DualQuaternion r1 d1) (DualQuaternion r2 d2) = DualQuaternion (qMul r1 r2) (qAdd (qMul d1 r2) (qMul r1 d2))
