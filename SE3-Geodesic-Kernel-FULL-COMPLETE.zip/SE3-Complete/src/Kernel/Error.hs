
{-# LANGUAGE DeriveGeneric #-}

module Kernel.Error where

import GHC.Generics
import Control.DeepSeq

data KernelError = ArithmeticError String | InvalidConstraint String | SaturationDetected String | InvalidInput String | ConvergenceFailed String | UnknownError String deriving (Show, Eq, Generic, NFData)
data Severity = Critical | High | Medium | Low deriving (Show, Eq, Ord, Generic, NFData)

displayError (ArithmeticError msg) = "ARITHMETIC ERROR: " ++ msg
displayError (InvalidConstraint msg) = "CONSTRAINT VIOLATION: " ++ msg
displayError (SaturationDetected msg) = "SATURATION: " ++ msg
displayError (InvalidInput msg) = "INVALID INPUT: " ++ msg
displayError (ConvergenceFailed msg) = "CONVERGENCE FAILED: " ++ msg
displayError (UnknownError msg) = "UNKNOWN: " ++ msg

errorSeverity (SaturationDetected _) = Critical
errorSeverity (ArithmeticError _) = Critical
errorSeverity (InvalidConstraint _) = High
errorSeverity (ConvergenceFailed _) = Medium
errorSeverity _ = High

isRecoverable (ConvergenceFailed _) = True
isRecoverable (SaturationDetected _) = True
isRecoverable _ = False
