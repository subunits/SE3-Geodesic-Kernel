
{-# LANGUAGE NoImplicitPrelude #-}

module Kernel.Consensus where

import Prelude
import Kernel.Core

topEntity _ agentL agentH = (agentL, agentH, Scalar32 0)
verifyConstraints _ = True
consensusMetric _ _ = Scalar32 0
