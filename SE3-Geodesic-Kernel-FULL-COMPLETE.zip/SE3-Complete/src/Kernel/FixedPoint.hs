
{-# LANGUAGE NoImplicitPrelude #-}

module Kernel.FixedPoint where

import Prelude
import Kernel.Core
import Data.Bits

scalarShiftL (Scalar32 x) n | n < 0 = Scalar32 x | n > 30 = if x > 0 then Scalar32 maxBound else Scalar32 minBound | otherwise = Scalar32 (max (-32768) (min 32767 (x `shiftL` n)))
scalarShiftR (Scalar32 x) n | n < 0 = Scalar32 x | otherwise = Scalar32 (x `shiftR` n)
scalarMax a b = if a >= b then a else b
scalarMin a b = if a <= b then a else b
scalarEq (Scalar32 a) (Scalar32 b) = a == b
scalarLt (Scalar32 a) (Scalar32 b) = a < b
scalarToDouble = fromScalar32
doubleToScalar d | isNaN d || isInfinite d = Scalar32 0 | d >= 32768 = Scalar32 maxBound | d < -32768 = Scalar32 minBound | otherwise = Scalar32 (round (d * 65536))

isNaN x = x /= x
isInfinite x = x == 1.0/0.0 || x == -1.0/0.0
