
{-# LANGUAGE OverloadedStrings #-}

module Main where

import Test.Tasty
import Test.Tasty.HUnit

main :: IO ()
main = defaultMain tests

tests :: TestTree
tests = testGroup "Integration Tests" [simulationTests, hardwareTests, convergenceTests]

simulationTests :: TestTree
simulationTests = testGroup "Simulations" [testCase "single agent" $ True @? "Single agent", testCase "dual agent" $ True @? "Dual agent"]

hardwareTests :: TestTree
hardwareTests = testGroup "Hardware" [testCase "fixed-point" $ True @? "Fixed-point", testCase "saturation" $ True @? "Saturation"]

convergenceTests :: TestTree
convergenceTests = testGroup "Convergence" [testCase "velocity" $ True @? "Converges"]
