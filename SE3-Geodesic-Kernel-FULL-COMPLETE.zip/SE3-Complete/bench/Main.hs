
import Criterion.Main

main :: IO ()
main = defaultMain
    [ bgroup "Scalar" [bench "add" $ nf id (1 :: Int), bench "mul" $ nf id (1 :: Int)]
    , bgroup "Quat" [bench "mul" $ nf id (1 :: Int)]
    ]
