
{-# LANGUAGE NoImplicitPrelude #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE RecordWildCards #-}

module Kernel.Core where

import Prelude hiding ((.), id)
import GHC.Generics
import Control.DeepSeq
import Data.Bits

newtype Scalar32 = Scalar32 Int32 deriving (Show, Eq, Ord, Generic, NFData)
newtype Scalar16 = Scalar16 Int16 deriving (Show, Eq, Ord, Generic, NFData)

data Quaternion = Quaternion {qW :: !Scalar32, qX :: !Scalar32, qY :: !Scalar32, qZ :: !Scalar32} deriving (Show, Eq, Generic, NFData)
data DualQuaternion = DualQuaternion {realPart :: !Quaternion, dualPart :: !Quaternion} deriving (Show, Eq, Generic, NFData)
data Agent = Agent {agentPos :: !DualQuaternion, agentVel :: !Scalar32, agentResonance :: !Scalar32, agentMass :: !Scalar32} deriving (Show, Eq, Generic, NFData)

toScalar32 d | isNaN d || isInfinite d = Left "Non-finite" | d >= 32768 = Right (Scalar32 maxBound) | d < -32768 = Right (Scalar32 minBound) | otherwise = Right (Scalar32 (round (d * 65536)))
fromScalar32 (Scalar32 x) = fromIntegral x / 65536

scalarAdd (Scalar32 a) (Scalar32 b) = let sum = a + b in if (a > 0 && b > 0 && sum < 0) || (a < 0 && b < 0 && sum > 0) then if a > 0 then Scalar32 maxBound else Scalar32 minBound else Scalar32 sum
scalarMul (Scalar32 a) (Scalar32 b) = let extended = (fromIntegral a :: Int64) * fromIntegral b; shifted = extended `shiftR` 16; saturated = max (-32768) (min 32767 shifted) in Scalar32 (fromIntegral saturated)
scalarDiv _ (Scalar32 0) = Scalar32 0
scalarDiv (Scalar32 a) (Scalar32 b) = let extended = (fromIntegral a :: Int64) `shiftL` 16; result = extended `div` fromIntegral b; saturated = max (-32768) (min 32767 result) in Scalar32 (fromIntegral saturated)
scalarSub a b = scalarAdd a (scalarNegate b)
scalarNegate (Scalar32 x) | x == minBound = Scalar32 maxBound | otherwise = Scalar32 (-x)

validateScalar _ = Right ()
validateQuaternion _ = Right ()
validateAgent _ = Right ()

isNaN x = x /= x
isInfinite x = x == 1.0/0.0 || x == -1.0/0.0
